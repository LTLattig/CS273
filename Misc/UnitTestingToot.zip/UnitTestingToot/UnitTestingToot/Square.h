#pragma once
#ifndef SQUARE_H_

#define SQUARE_H_

	bool isSquare(int a, int b, int c, int d);

#endif /*SQUARE_H_*/ 