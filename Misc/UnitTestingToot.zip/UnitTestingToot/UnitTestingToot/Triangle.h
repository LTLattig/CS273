#pragma once
#ifndef TRIANGLE_H_
#define TRIANGLE_H_

bool isTriangle(int a, int b, int c);

#endif /*TRIANGLE_H_*/